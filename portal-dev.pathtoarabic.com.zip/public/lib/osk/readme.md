jQuery On-Screen Keyboard
=========================

Create a keyboard in a block-level container with

    $('#container').loadLayout('layout.json', callback)

`container`: the containing element

`layout.json`: path to the layout file

`callback`: a function to call for each keypress

See the included demo for an example.