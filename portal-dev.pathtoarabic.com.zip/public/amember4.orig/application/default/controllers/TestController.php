<?php

class TestController extends Am_Controller
{
    function indexAction()
    {
    }
}