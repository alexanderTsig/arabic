
MODULE INSTALLATION

1. Upload module code to folder 'amember/application/'
2. Enable module at aMember CP -> Configuration -> Setup/Configuration -> Plugins
3. Visit module configuration section
   aMember CP -> Configuration -> Setup/Configuration -> [Module Name]
   to configure module. Module-specific readme is displayed this page at
   bottom. (Some modules may not require special configuration)
