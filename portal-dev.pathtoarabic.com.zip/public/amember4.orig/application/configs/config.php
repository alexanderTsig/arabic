<?php
/**
*  aMember Pro Config File
*
*     Author: Alex Scott
*      Email: alex@cgi-central.net
*        Web: http://www.amember.com/
*    FileName $RCSfile$
*    Release: 4.1.13 ($Revision$)
*
* Please direct bug reports,suggestions or feedback to the cgi-central forums.
* http://www.cgi-central.net/forums
*
* aMember PRO is a commercial software. Any distribution is strictly prohibited.
*/

return array(
	'db' => array(
		'mysql' => array(
			'db'    => 'amember4-dev',
			'user'  => 'amember',
			'pass'  => 'c7qIvi2u',
			'host'  => 'localhost',
			'prefix' => 'am_',
			'port'  => '',
		),
	),
);
