/**
 * You can place your custom JS scripts here
 * it is better to write everything custom here
 * because this file won't be replaced during upgrade
 * Don't forget to rename this file to "site.js"
 */