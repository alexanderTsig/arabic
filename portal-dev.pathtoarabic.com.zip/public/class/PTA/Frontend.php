<?php

namespace PTA;

class Frontend {

}
