<?php

namespace PTA;

class ImgPicker extends \ImgPicker {
	
}
