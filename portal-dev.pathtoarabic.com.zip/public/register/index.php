<?php

header('Location: //portal.pathtoarabic.com/amember4/signup');
