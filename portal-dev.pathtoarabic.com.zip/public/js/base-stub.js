(function(pta, $, undefined) {
	pta.dispatchTable = {};
}(window.pta = window.pta || {}, jQuery));
